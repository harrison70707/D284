package com.example.demo.bootstrap;

import com.example.demo.domain.InhousePart;
import com.example.demo.domain.OutsourcedPart;
import com.example.demo.domain.Part;
import com.example.demo.domain.Product;
import com.example.demo.repositories.OutsourcedPartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import com.example.demo.service.OutsourcedPartService;
import com.example.demo.service.OutsourcedPartServiceImpl;
import com.example.demo.service.ProductService;
import com.example.demo.service.ProductServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

/**
 *
 *
 *
 *
 */
@Component
public class BootStrapData implements CommandLineRunner {

    private final PartRepository partRepository;
    private final ProductRepository productRepository;

    private final OutsourcedPartRepository outsourcedPartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository, OutsourcedPartRepository outsourcedPartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.outsourcedPartRepository=outsourcedPartRepository;
    }

    @Override
    public void run(String... args) throws Exception {

       /*
        OutsourcedPart o= new OutsourcedPart();
        o.setCompanyName("Western Governors University");
        o.setName("out test");
        o.setInv(5);
        o.setPrice(20.0);
        o.setId(100L);
        outsourcedPartRepository.save(o);
        OutsourcedPart thePart=null;
        List<OutsourcedPart> outsourcedParts=(List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            if(part.getName().equals("out test"))thePart=part;
        }

        System.out.println(thePart.getCompanyName());
        */
        List<OutsourcedPart> outsourcedParts=(List<OutsourcedPart>) outsourcedPartRepository.findAll();
        for(OutsourcedPart part:outsourcedParts){
            System.out.println(part.getName()+" "+part.getCompanyName());
        }

        /*
        Product bicycle= new Product("bicycle",100.0,15);
        Product unicycle= new Product("unicycle",100.0,15);
        productRepository.save(bicycle);
        productRepository.save(unicycle);
        */
        if (productRepository.count() == 0) {
            Product computer1 = new Product("Bell XF2000", 1290.99, 48, 0, 100);
            productRepository.save(computer1);
            Product computer2 = new Product("GP 14i Processor", 3490.99, 25, 0, 100);
            productRepository.save(computer2);
            Product computer3 = new Product("NovaView 24 Monitor", 1990.99, 32, 0, 100);
            productRepository.save(computer3);
            Product computer4 = new Product("Onion X2 Laptop", 899.99, 97, 0, 100);
            productRepository.save(computer4);
            Product computer5 = new Product("Helix 1TB SSD", 1490.99, 22, 0, 100);
            productRepository.save(computer5);
        }
        if (partRepository.count() == 0) {

            InhousePart part1 = new InhousePart();
            part1.setName("Mouse");
            part1.setPrice(25.99);
            part1.setInv(63);
            part1.setMinInv(0);
            part1.setMaxInv(200);
            partRepository.save(part1);
            Part part2 = new InhousePart();
            part2.setName("Keyboard");
            part2.setPrice(49.99);
            part2.setInv(75);
            part2.setMinInv(0);
            part2.setMaxInv(200);
            partRepository.save(part2);
            InhousePart part3 = new InhousePart();
            part3.setName("Monitor");
            part3.setPrice(179.99);
            part3.setInv(34);
            part3.setMinInv(0);
            part3.setMaxInv(200);
            partRepository.save(part3);
            InhousePart part4 = new InhousePart();
            part4.setName("Motherboard");
            part4.setPrice(129.99);
            part4.setInv(22);
            part4.setMinInv(0);
            part4.setMaxInv(200);
            partRepository.save(part4);
            InhousePart part5 = new InhousePart();
            part5.setName("RAM Stick");
            part5.setPrice(69.99);
            part5.setInv(58);
            part5.setMinInv(0);
            part5.setMaxInv(200);
            partRepository.save(part5);
        }
        System.out.println("Started in Bootstrap");
        System.out.println("Number of Products"+productRepository.count());
        System.out.println(productRepository.findAll());
        System.out.println("Number of Parts"+partRepository.count());
        System.out.println(partRepository.findAll());

    }
}
